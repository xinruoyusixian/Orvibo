// index.js
// 获取应用实例
const app = getApp()
import mqtt from '../../utils/js/mqtt.min.js'; //加载mqtt库




Page({
    data: {
        uid: "d023980739a4c6d611f59b9e351b791c", //用户密钥，巴法云控制台获取
        topic: "power001", //传输温湿度的主题，控制台创建
        device_status: "离线", // 显示led是否在线的字符串，默认离线
        ledOnOff: "关闭",
        checked: false, //led的状态。默认led关闭
        ledicon: "/utils/img/lightoff.png", //显示led图标的状态。默认是关闭状态图标
        client: null, //mqtt客户端，默认为空
        showWait: false,
        showState: true,
        isShowConfirm: true,
        pwd: '',
        showPWD: true,
        showInfo: false,
        passCode: "252816",

    },

    ctime(_h) {
        var that = this
        //shijianchuo是整数，否则要parseInt转换
        var time = new Date();
        var h = time.getHours() + _h;
        if (h >= 24) {
            h = h - 24;
        }
        var mm = time.getMinutes();
        var s = time.getSeconds();
        return h + ':' + mm;
    },

    mqttConnect() {
        var that = this
        var msgs = ["", "", "", "", "", "", ""]
        //MQTT连接的配置
        var options = {
            keepalive: 60, //60s ，表示心跳间隔
            clean: true, //cleanSession不保持持久会话
            protocolVersion: 4, //MQTT v3.1.1
            clientId: this.data.uid
        }
        //初始化mqtt连接
        this.data.client = mqtt.connect('wxs://bemfa.com:9504/wss', options)
        // 连接mqtt服务器
        this.data.client.on('connect', function () {
            console.log('连接服务器成功')
            //订阅主题
            that.data.client.subscribe(that.data.topic, function (err) {
                if (err) {
                    console.log(err)
                }
            })
        })

        
        //接收消息

        that.data.client.on('message', function (topic, message) {
            console.log(topic)
            var msg = message.toString()
            if (msg == "r-on" && that.data.checked == false) { //如果单片机处于打开状态
                that.ChangePic("on")
            }
            if (msg == "r-off" && that.data.checked == true) {
                that.ChangePic("off")
            }
            if (msg != "on" && msg != "off") {
                if (msg == "r-on") {
                    msg = "已开启！";
                }
                if (msg == "r-off") {
                    msg = "已关闭！";
                }
                msgs.splice(0, 0, msg + "\n");
                msgs.pop()
                that.setData({
                    info0: msgs[0],
                    info1: msgs[1],
                    info2: msgs[2],
                    info3: msgs[3],
                    info4: msgs[4],
                })
            }
            //打印消息
            console.log('收到消息：' + msg)
        })

        //断线重连
        this.data.client.on("reconnect", function () {
            console.log("重新连接")
        });


    },

    //屏幕打开时执行的函数
    onLoad() {
        var pass = wx.getStorageSync('pass');
        if (pass == this.data.passCode) {
            this.setData({
                isShowConfirm: false
            })
        }

        //连接mqtt
        this.mqttConnect()
        //检查设备是否在线
        this.getOnline()
        this.data.client.publish(this.data.topic, 'get')
        //检查设备是打开还是关闭
    },
    //控制灯的函数1，小滑块点击后执行的函数
    onChange2() {
        var that = this
        if (that.data.checked == true) { //如果是打开操作
            that.setData({
                showWait: true,
                showState: false
            })
            this.data.client.publish(this.data.topic, 'off')
            console.log("关闭")
        } else {
            that.setData({
                showWait: true,
                showState: false
            })
            this.data.client.publish(this.data.topic, 'on')
            console.log("打开")
        }
    },
    set2h() {
        this.data.client.publish(this.data.topic, 'add#' + this.ctime(2) + '#0#0')
        this.data.client.publish(this.data.topic, 'on')
    },
    set4h() {
        this.data.client.publish(this.data.topic, 'add#' + this.ctime(4) + '#0#0')
        this.data.client.publish(this.data.topic, 'on')
    },
    set6h() {
        this.data.client.publish(this.data.topic, 'add#' + this.ctime(6) + '#0#0')
        this.data.client.publish(this.data.topic, 'on')
    },
    set8h() {
        this.data.client.publish(this.data.topic, 'add#' + this.ctime(8) + '#0#0')
        this.data.client.publish(this.data.topic, 'on')
    },
    delTask() {
        this.data.client.publish(this.data.topic, 'del#1')
    },
    //点击led图片执行的函数
    ChangePic(msg) {
        var that = this
        //如果点击前是打开状态，现在更换为关闭状态，并更换图标，完成状态切换
        if (msg == "off") {

            this.setData({
                showWait: false,
                showState: true,
                ledicon: "/utils/img/lightoff.png", //设置led图片为off
                checked: false //设置led状态为false
            });
        }
        if (msg == "on") {
            //如果点击前是关闭状态，现在更换为打开状态，并更换图标，完成状态切换
            that.setData({
                showWait: false,
                showState: true,
                ledicon: "/utils/img/lighton.png", //设置led图片为on
                checked: true //设置led状态为true
            });

        }
    },
    getOnline() {
        var that = this
        //请求设备状态,检查设备是否在线
        //api 接口详细说明见巴法云接入文档
        wx.request({
            url: 'https://api.bemfa.com/mqtt/status/', //状态api接口，详见巴法云接入文档
            data: {
                uid: that.data.uid,
                topic: that.data.topic,
            },
            header: {
                'content-type': "application/x-www-form-urlencoded"
            },
            success(res) {
                console.log(res)
                console.log(res.data)
                if (res.data.status === "online") {
                    that.setData({
                        showWait: false,
                        device_status: "在线"
                    })
                } else {
                    that.setData({
                        showWait: false,
                        device_status: "离线"
                    })
                }
                console.log(that.data.device_status)
            }
        })
    },


    setValue: function (e) {

        this.data.pwd = e.detail.value
        console.log(this.data.pwd)

    },

    cancel() {
        var that = this

        that.setData({
            // isShowConfirm: false,
        })
        console.log(6)
    },
    confirmAcceptance() {
        var that = this

        if (this.data.pwd == this.data.passCode) {
            that.setData({
                isShowConfirm: false,
            });
            wx.setStorageSync("pass", this.data.pwd);
        }
        else {
            that.setData({
                showPWD: false,
                showInfo: true,
            })
            setTimeout(function () {
                that.setData({
                    showPWD: true,
                    showInfo: false,
                })

            }, 2000)
        }

    },

})